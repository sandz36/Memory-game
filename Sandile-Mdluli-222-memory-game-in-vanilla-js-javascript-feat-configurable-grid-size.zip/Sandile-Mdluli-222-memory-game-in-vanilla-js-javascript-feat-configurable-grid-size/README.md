Memory game web app (222)
For raw project instructions see: http://syllabus.africacode.net/projects/memory-game/part-1/